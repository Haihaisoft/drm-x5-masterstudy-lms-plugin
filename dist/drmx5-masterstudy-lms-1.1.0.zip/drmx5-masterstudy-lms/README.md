# DRM-X 5.0 Integration for WordPress + MasterStudy LMS

This plugin connects WordPress and MasterStudy LMS to DRM-X 5.0 and embeds protected
videos with the ZJGet player.

## Features

- Requires a WordPress login before a DRM-X license can be obtained.
- Verifies that the current user is enrolled in the MasterStudy LMS course whose post ID
  is stored in the DRM-X License Profile `YourProductID` field.
- Supports multiple course IDs separated with a hyphen, such as `123-124`. The first
  course in the list that the user can access is used.
- Creates the corresponding DRM-X user automatically when needed.
- Blocks DRM-X users who are revoked or locked.
- Supports International (`5.drm-x.com`) and China (`5.drm-x.cn`) services.
- Supports one or more fixed RightsIDs with automatic rights updates, or the RightsID supplied
  by the DRM-X License Profile through ZJGet POST data without a rights update.
- Adds the `[zjget-player]URL[/zjget-player]` shortcode.
- Includes English source text and a Simplified Chinese translation.

## Installation and setup

1. Zip the `drmx5-masterstudy-lms` directory and install it through **Plugins > Add New >
   Upload Plugin**, or copy it into `wp-content/plugins/`.
2. Install and activate MasterStudy LMS, then activate this plugin.
3. Open **Settings > DRM-X 5.0** and configure `AdminEmail`,
   `WebServiceAuthStr`, `GroupID`, service area, and RightsID mode.
4. Copy the Integration Address shown on that settings page into the DRM-X 5.0
   custom login/integration URL setting. The endpoint filename is `licstore5.php`.
5. Put the numeric WordPress post ID of the MasterStudy LMS course in the License Profile
   `YourProductID` field. Use `123-124` to authorize enrollment in either course.
6. Embed one protected video on a page or MasterStudy LMS lesson with:

   `[zjget-player]https://example.com/protected-video.mp4[/zjget-player]`

Use HTTPS for the WordPress website. The server must have the PHP SOAP extension.

## Fixed RightsIDs

In fixed mode, enter one or more numeric RightsIDs separated by English commas,
for example `123,456,789`. One ID is chosen at random for each license request.
The plugin reads its existing description with `GetRights` and preserves it when
updating the rights, then issues the license with that same ID. Multiple IDs reduce,
but do not eliminate, concurrent rights conflicts. POST mode is unchanged.

## Fixed RightsID dates

When fixed mode is enabled, the plugin uses the start and end times in the user's
MasterStudy course record. If no valid start or end time is available, the current
request time and a ten-year expiration are used. The DRM-X
`ExpirationAfterFirstUse` value is `-1`.

---

# DRM-X 5.0 WordPress + MasterStudy LMS 集成

本插件用于连接 WordPress、MasterStudy LMS 与 DRM-X 5.0，并通过 ZJGet 播放器嵌入加密视频。

## 主要功能

- 获取 DRM-X 许可证前验证 WordPress 登录状态。
- 根据 DRM-X 许可证模板 `YourProductID` 中填写的 MasterStudy LMS 课程文章 ID 检查用户是否已加入课程。
- 支持使用连字符填写多个课程 ID，例如 `123-124`；按顺序采用用户有权访问的第一个课程。
- DRM-X 用户不存在时自动创建。
- DRM-X 用户被吊销或锁定时拒绝发放许可证。
- 支持国际版 `5.drm-x.com` 和中国版 `5.drm-x.cn`。
- 支持填写一个或多个固定 RightsID 并自动更新权限；也可读取 DRM-X 许可证模板通过 ZJGet POST 提交的 RightsID，且不更新权限。
- 提供 `[zjget-player]URL[/zjget-player]` 简码。
- 管理页面和提示信息支持英文、简体中文。

## 安装和设置

1. 将 `drmx5-masterstudy-lms` 文件夹压缩成 ZIP，通过 WordPress 的“插件 > 安装插件 > 上传插件”安装；也可以直接复制到 `wp-content/plugins/`。
2. 安装并启用 MasterStudy LMS，然后启用本插件。
3. 打开“设置 > DRM-X 5.0”，填写 `AdminEmail`、`WebServiceAuthStr`、`GroupID`，并选择服务区域和 RightsID 模式。
4. 把设置页面显示的集成地址复制到 DRM-X 5.0 后台的自定义登录/集成地址中。许可证页面文件名为 `licstore5.php`。
5. 在 DRM-X 许可证模板 `YourProductID` 中填写 MasterStudy LMS 课程的 WordPress 文章 ID。多个课程使用 `123-124` 格式。
6. 在 WordPress 页面或 MasterStudy LMS 课时中添加：

   `[zjget-player]https://example.com/protected-video.mp4[/zjget-player]`

WordPress 网站应使用 HTTPS，服务器必须启用 PHP SOAP 扩展。

## 多个固定 RightsID

固定模式可填写多个数字 RightsID，以英文逗号分隔，例如 `123,456,789`。每次申请许可证时随机选取一个，先通过 `GetRights` 读取并保留该权限原有描述，再更新权限并使用同一个 ID 发证。多个 ID 可降低并发时权限数据串用的概率，但不能完全消除。POST 模式不变。

## 固定 RightsID 的日期

固定模式优先使用当前用户在 MasterStudy 课程记录中的开始和截止时间；缺少有效时间时，开始日期使用当前申请时间，截止日期设置为申请许可证之日起 10 年。`ExpirationAfterFirstUse` 固定为 `-1`。


